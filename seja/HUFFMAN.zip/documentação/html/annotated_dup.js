var annotated_dup =
[
    [ "data", "structdata.html", "structdata" ],
    [ "map", "structmap.html", "structmap" ],
    [ "node", "structnode.html", "structnode" ]
];