var structdata =
[
    [ "byte", "structdata.html#a609166f7bf42431c3d1676913fd60398", null ],
    [ "frequency", "structdata.html#a5b9b2a65114f8263c48bf00e79b9d677", null ]
];