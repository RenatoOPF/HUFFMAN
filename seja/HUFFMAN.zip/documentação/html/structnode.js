var structnode =
[
    [ "data", "structnode.html#ae82853bbf3b0d2b71de205ae40799555", null ],
    [ "left", "structnode.html#a7cbff55ff448f557223f79299056e9b1", null ],
    [ "next", "structnode.html#aad210fa7c160a49f6b9a3ffee592a2bc", null ],
    [ "right", "structnode.html#abdc86d4c8604c481752953af3235fc47", null ]
];