var searchData=
[
  ['data_0',['data',['../common_8h.html#a493583f6fc164cf849745e01e4c04ab5',1,'common.h']]],
  ['dictionary_1',['dictionary',['../common_8h.html#aa3e6f6912c3130eaa67226684b97cdfc',1,'common.h']]]
];
