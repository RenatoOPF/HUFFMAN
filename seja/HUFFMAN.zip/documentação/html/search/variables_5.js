var searchData=
[
  ['right_0',['right',['../structnode.html#abdc86d4c8604c481752953af3235fc47',1,'node']]]
];
