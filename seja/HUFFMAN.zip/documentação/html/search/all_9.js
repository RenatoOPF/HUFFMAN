var searchData=
[
  ['next_0',['next',['../structnode.html#aad210fa7c160a49f6b9a3ffee592a2bc',1,'node']]],
  ['node_1',['node',['../structnode.html',1,'node'],['../common_8h.html#af4aeda155dbe167f1c1cf38cb65bf324',1,'node:&#160;common.h']]]
];
