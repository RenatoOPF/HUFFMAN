var searchData=
[
  ['symbol_0',['symbol',['../structmap.html#a30a03d02d5812d81020a0e07c6449196',1,'map']]],
  ['symbol_5fsize_1',['symbol_size',['../structmap.html#a72240e7ead07ea0e9cb7deca9a554892',1,'map']]]
];
