var searchData=
[
  ['next_0',['next',['../structnode.html#aad210fa7c160a49f6b9a3ffee592a2bc',1,'node']]]
];
