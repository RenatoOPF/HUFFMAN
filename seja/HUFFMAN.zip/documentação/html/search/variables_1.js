var searchData=
[
  ['data_0',['data',['../structnode.html#ae82853bbf3b0d2b71de205ae40799555',1,'node']]]
];
