var searchData=
[
  ['data_0',['data',['../structdata.html',1,'data'],['../structnode.html#ae82853bbf3b0d2b71de205ae40799555',1,'node::data'],['../common_8h.html#a493583f6fc164cf849745e01e4c04ab5',1,'data:&#160;common.h']]],
  ['dictionary_1',['dictionary',['../common_8h.html#aa3e6f6912c3130eaa67226684b97cdfc',1,'common.h']]]
];
