var searchData=
[
  ['read_5fbytes_0',['read_bytes',['../compress_8c.html#a9a4d29a21deb9224de804d23c04089eb',1,'read_bytes(int *bytes_freq, FILE *input):&#160;compress.c'],['../compress_8h.html#a9a4d29a21deb9224de804d23c04089eb',1,'read_bytes(int *bytes_freq, FILE *input):&#160;compress.c']]],
  ['remap_1',['remap',['../compress_8c.html#ab07c802fd7d7e2971c0b40b2e693536d',1,'remap(node *root, dictionary bytes_map[256], unsigned long new_symbol, int i, int bit):&#160;compress.c'],['../compress_8h.html#ab07c802fd7d7e2971c0b40b2e693536d',1,'remap(node *root, dictionary bytes_map[256], unsigned long new_symbol, int i, int bit):&#160;compress.c']]],
  ['right_2',['right',['../structnode.html#abdc86d4c8604c481752953af3235fc47',1,'node']]],
  ['right_5fshift_3',['right_shift',['../common_8c.html#ade23cc8cc082d56c08fb8fdfde1dc159',1,'right_shift(unsigned char byte, int shift_ammout):&#160;common.c'],['../common_8h.html#ade23cc8cc082d56c08fb8fdfde1dc159',1,'right_shift(unsigned char byte, int shift_ammout):&#160;common.c']]]
];
