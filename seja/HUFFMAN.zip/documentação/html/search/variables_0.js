var searchData=
[
  ['byte_0',['byte',['../structdata.html#a609166f7bf42431c3d1676913fd60398',1,'data']]]
];
