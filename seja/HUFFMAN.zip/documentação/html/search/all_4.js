var searchData=
[
  ['frequency_0',['frequency',['../structdata.html#a5b9b2a65114f8263c48bf00e79b9d677',1,'data']]]
];
