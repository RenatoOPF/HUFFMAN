var structmap =
[
    [ "symbol", "structmap.html#a30a03d02d5812d81020a0e07c6449196", null ],
    [ "symbol_size", "structmap.html#a72240e7ead07ea0e9cb7deca9a554892", null ]
];